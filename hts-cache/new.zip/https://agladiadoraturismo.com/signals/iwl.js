<!DOCTYPE html>
<!--[if IE 9 ]>   <html class="no-js oldie ie9 ie" lang="pt-BR" > <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html class="no-js" lang="pt-BR" > <!--<![endif]-->
<head>
        <meta charset="UTF-8" >
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- devices setting -->
        <meta name="viewport"   content="initial-scale=1,user-scalable=no,width=device-width">

<!-- outputs by wp_head -->
<title>Página não encontrada &#8211; A Gladiadora Turismo</title>
<meta name='robots' content='max-image-preview:large' />
<script type='application/javascript'>console.log('PixelYourSite Free version 9.2.0');</script>
<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Feed para A Gladiadora Turismo &raquo;" href="https://agladiadoraturismo.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Feed de comentários para A Gladiadora Turismo &raquo;" href="https://agladiadoraturismo.com/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/agladiadoraturismo.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.6.2"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel='stylesheet' id='sbi_styles-css' href='https://agladiadoraturismo.com/wp-content/plugins/instagram-feed/css/sbi-styles.min.css?ver=6.0.8' type='text/css' media='all' />
<link rel='stylesheet' id='shopengine-public-css' href='https://agladiadoraturismo.com/wp-content/plugins/shopengine/assets/css/shopengine-public.css?ver=2.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='shopengine-widget-frontend-css' href='https://agladiadoraturismo.com/wp-content/plugins/shopengine/widgets/init/assets/css/widget-frontend.css?ver=2.5.1' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://agladiadoraturismo.com/wp-includes/css/dist/block-library/style.min.css?ver=6.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='wc-blocks-vendors-style-css' href='https://agladiadoraturismo.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-vendors-style.css?ver=8.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='wc-blocks-style-css' href='https://agladiadoraturismo.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-style.css?ver=8.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='jet-engine-frontend-css' href='https://agladiadoraturismo.com/wp-content/plugins/jet-engine/assets/css/frontend.css?ver=3.0.3' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://agladiadoraturismo.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.6.4' type='text/css' media='all' />
<link rel='stylesheet' id='custom-style-css' href='https://agladiadoraturismo.com/wp-content/plugins/extensions-for-elementor-form/assets/style.css?ver=1.3.6' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-layout-css' href='https://agladiadoraturismo.com/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=7.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css' href='https://agladiadoraturismo.com/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=7.0.0' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css' href='https://agladiadoraturismo.com/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=7.0.0' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='wp-ulike-css' href='https://agladiadoraturismo.com/wp-content/plugins/wp-ulike/assets/css/wp-ulike.min.css?ver=4.6.4' type='text/css' media='all' />
<link rel='stylesheet' id='auxin-base-css' href='https://agladiadoraturismo.com/wp-content/themes/phlox/css/base.css?ver=2.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='auxin-front-icon-css' href='https://agladiadoraturismo.com/wp-content/themes/phlox/css/auxin-icon.css?ver=2.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='auxin-main-css' href='https://agladiadoraturismo.com/wp-content/themes/phlox/css/main.css?ver=2.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='wpdreams-asl-basic-css' href='https://agladiadoraturismo.com/wp-content/plugins/ajax-search-lite/css/style.basic.css?ver=4.12.3' type='text/css' media='all' />
<link rel='stylesheet' id='wpdreams-asl-instance-css' href='https://agladiadoraturismo.com/wp-content/plugins/ajax-search-lite/css/style-curvy-red.css?ver=4.12.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.24.4' type='text/css' media='all' />
<link rel='stylesheet' id='widget-image-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/css/widget-image.min.css?ver=3.24.4' type='text/css' media='all' />
<link rel='stylesheet' id='e-animation-bounce-in-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/lib/animations/styles/e-animation-bounce-in.min.css?ver=3.24.4' type='text/css' media='all' />
<link rel='stylesheet' id='e-animation-fadeInUp-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/lib/animations/styles/fadeInUp.min.css?ver=3.24.4' type='text/css' media='all' />
<link rel='stylesheet' id='e-animation-fadeIn-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/lib/animations/styles/fadeIn.min.css?ver=3.24.4' type='text/css' media='all' />
<link rel='stylesheet' id='widget-icon-list-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=3.24.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.31.0' type='text/css' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/lib/swiper/v8/css/swiper.min.css?ver=8.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='e-swiper-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/css/conditionals/e-swiper.min.css?ver=3.24.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-2113-css' href='https://agladiadoraturismo.com/wp-content/uploads/elementor/css/post-2113.css?ver=1727696469' type='text/css' media='all' />
<link rel='stylesheet' id='auxin-elementor-base-css' href='https://agladiadoraturismo.com/wp-content/themes/phlox/css/other/elementor.css?ver=2.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='auxin-elementor-widgets-css' href='https://agladiadoraturismo.com/wp-content/plugins/auxin-elements/admin/assets/css/elementor-widgets.css?ver=2.10.5' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css' href='https://agladiadoraturismo.com/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.17' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css' href='https://agladiadoraturismo.com/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=6.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.24.2' type='text/css' media='all' />
<link rel='stylesheet' id='jet-sticky-frontend-css' href='https://agladiadoraturismo.com/wp-content/plugins/jetsticky-for-elementor/assets/css/jet-sticky-frontend.css?ver=1.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-70-css' href='https://agladiadoraturismo.com/wp-content/uploads/elementor/css/post-70.css?ver=1727696470' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-71-css' href='https://agladiadoraturismo.com/wp-content/uploads/elementor/css/post-71.css?ver=1727696470' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-ekiticons-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementskit-lite/modules/elementskit-icon-pack/assets/css/ekiticons.css?ver=2.7.3' type='text/css' media='all' />
<link rel='stylesheet' id='shopengine-modal-styles-css' href='https://agladiadoraturismo.com/wp-content/plugins/shopengine/assets/css/shopengine-modal.css?ver=2.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='wp-color-picker-css' href='https://agladiadoraturismo.com/wp-admin/css/color-picker.min.css?ver=6.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='shopengine-swatches-loop-css-css' href='https://agladiadoraturismo.com/wp-content/plugins/shopengine/modules/swatches/loop-product-support/assets/swatches.css?ver=1730832354' type='text/css' media='all' />
<link rel='stylesheet' id='shopengine-wishlist-css' href='https://agladiadoraturismo.com/wp-content/plugins/shopengine/modules/wishlist/assets/css/wishlist.css?ver=2.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='shopengine-comparison-css' href='https://agladiadoraturismo.com/wp-content/plugins/shopengine/modules/comparison/assets/css/comparison.css?ver=6.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='shopengine-css-front-css' href='https://agladiadoraturismo.com/wp-content/plugins/shopengine/modules/swatches/assets/css/frontend.css?ver=2.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='auxin-fonts-google-css' href='//fonts.googleapis.com/css?family=Montserrat%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2Cregular%2Citalic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CPoppins%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2Cregular%2Citalic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=1.4' type='text/css' media='all' />
<link rel='stylesheet' id='auxin-custom-css' href='https://agladiadoraturismo.com/wp-content/uploads/phlox/custom.css?ver=1.4' type='text/css' media='all' />
<link rel='stylesheet' id='ekit-widget-styles-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementskit-lite/widgets/init/assets/css/widget-styles.css?ver=2.7.3' type='text/css' media='all' />
<link rel='stylesheet' id='ekit-responsive-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementskit-lite/widgets/init/assets/css/responsive.css?ver=2.7.3' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CMontserrat%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=auto&#038;ver=6.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-brands-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin><script type="text/javascript" src="https://agladiadoraturismo.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/extensions-for-elementor-form/assets/script.js?ver=1.3.6" id="custom-js-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.7.0.0" id="js-cookie-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/shopengine/assets/js/shopengine-modal.js?ver=2.5.1" id="shopengine-modal-script-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/shopengine/modules/quick-view/assets/js/script.js?ver=6.6.2" id="shopengine-quickview-js"></script>
<script type="text/javascript" id="shopengine-wishlist-js-extra">
/* <![CDATA[ */
var shopEngineWishlist = {"product_id":"","resturl":"https:\/\/agladiadoraturismo.com\/wp-json\/","isLoggedIn":"","rest_nonce":"352a750552","wishlist_position":"bottom-right","wishlist_added_notice":"Your product is added to wishlist","wishlist_removed_notice":"Your product is removed from wishlist"};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/shopengine/modules/wishlist/assets/js/wishlist.js?ver=6.6.2" id="shopengine-wishlist-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/pixelyoursite/dist/scripts/jquery.bind-first-0.2.3.min.js?ver=6.6.2" id="jquery-bind-first-js"></script>
<script type="text/javascript" id="pys-js-extra">
/* <![CDATA[ */
var pysOptions = {"staticEvents":{"facebook":{"init_event":[{"delay":0,"type":"static","name":"PageView","pixelIds":["1480964285602159"],"eventID":"a272ad4d-fb3a-4daa-bab5-641cd40441cd","params":{"post_type":false,"plugin":"PixelYourSite","user_role":"guest","event_url":"agladiadoraturismo.com\/signals\/iwl.js"},"e_id":"init_event","ids":[],"hasTimeWindow":false,"timeWindow":0,"woo_order":"","edd_order":""}]}},"dynamicEvents":{"woo_add_to_cart_on_button_click":{"facebook":{"delay":0,"type":"dyn","name":"AddToCart","pixelIds":["1480964285602159"],"eventID":"03aac607-745b-4170-8ab3-1d147a1cedb8","params":{"post_type":false,"plugin":"PixelYourSite","user_role":"guest","event_url":"agladiadoraturismo.com\/signals\/iwl.js"},"e_id":"woo_add_to_cart_on_button_click","ids":[],"hasTimeWindow":false,"timeWindow":0,"woo_order":"","edd_order":""}}},"triggerEvents":[],"triggerEventTypes":[],"facebook":{"pixelIds":["1480964285602159"],"advancedMatching":[],"removeMetadata":false,"contentParams":[],"commentEventEnabled":true,"wooVariableAsSimple":false,"downloadEnabled":true,"formEventEnabled":true,"ajaxForServerEvent":true,"serverApiEnabled":true,"wooCRSendFromServer":false},"debug":"","siteUrl":"https:\/\/agladiadoraturismo.com","ajaxUrl":"https:\/\/agladiadoraturismo.com\/wp-admin\/admin-ajax.php","enable_remove_download_url_param":"1","cookie_duration":"7","last_visit_duration":"60","gdpr":{"ajax_enabled":false,"all_disabled_by_api":false,"facebook_disabled_by_api":false,"analytics_disabled_by_api":false,"google_ads_disabled_by_api":false,"pinterest_disabled_by_api":false,"bing_disabled_by_api":false,"facebook_prior_consent_enabled":true,"analytics_prior_consent_enabled":true,"google_ads_prior_consent_enabled":null,"pinterest_prior_consent_enabled":true,"bing_prior_consent_enabled":true,"cookiebot_integration_enabled":false,"cookiebot_facebook_consent_category":"marketing","cookiebot_analytics_consent_category":"statistics","cookiebot_google_ads_consent_category":null,"cookiebot_pinterest_consent_category":"marketing","cookiebot_bing_consent_category":"marketing","consent_magic_integration_enabled":false,"real_cookie_banner_integration_enabled":false,"cookie_notice_integration_enabled":false,"cookie_law_info_integration_enabled":false},"woo":{"enabled":true,"addToCartOnButtonEnabled":true,"addToCartOnButtonValueEnabled":true,"addToCartOnButtonValueOption":"price","singleProductId":null,"removeFromCartSelector":"form.woocommerce-cart-form .remove","addToCartCatchMethod":"add_cart_js"},"edd":{"enabled":false}};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/pixelyoursite/dist/scripts/public.js?ver=9.2.0" id="pys-js"></script>

<!-- Snippet do Google Analytics adicionado pelo Site Kit -->
<script type="text/javascript" src="https://www.googletagmanager.com/gtag/js?id=UA-204538927-1" id="google_gtagjs-js" async></script>
<script type="text/javascript" id="google_gtagjs-js-after">
/* <![CDATA[ */
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag('set', 'linker', {"domains":["agladiadoraturismo.com"]} );
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "UA-204538927-1", {"anonymize_ip":true});
gtag("config", "G-GB2XJC08HF");
/* ]]> */
</script>

<!-- Finalizar o snippet do Google Analytics adicionado pelo Site Kit -->
<script type="text/javascript" id="auxin-modernizr-js-extra">
/* <![CDATA[ */
var auxin = {"ajax_url":"https:\/\/agladiadoraturismo.com\/wp-admin\/admin-ajax.php","is_rtl":"","is_reponsive":"1","is_framed":"","frame_width":"20","wpml_lang":"en","uploadbaseurl":"https:\/\/agladiadoraturismo.com\/wp-content\/uploads"};
/* ]]> */
</script>
<script type="text/javascript" id="auxin-modernizr-js-before">
/* <![CDATA[ */
/* < ![CDATA[ */
function auxinNS(n){for(var e=n.split("."),a=window,i="",r=e.length,t=0;r>t;t++)"window"!=e[t]&&(i=e[t],a[i]=a[i]||{},a=a[i]);return a;}
/* ]]]]><![CDATA[> */
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/themes/phlox/js/solo/modernizr-custom.min.js?ver=2.9.1" id="auxin-modernizr-js"></script>
<link rel="https://api.w.org/" href="https://agladiadoraturismo.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://agladiadoraturismo.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.6.2" />
<meta name="generator" content="WooCommerce 7.0.0" />
<meta name="generator" content="Site Kit by Google 1.85.0" /><!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NXJ8J83');</script>
<!-- End Google Tag Manager -->	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<!-- Chrome, Firefox OS and Opera -->
<meta name="theme-color" content="rgb(244, 44, 55)" />
<!-- Windows Phone -->
<meta name="msapplication-navbutton-color" content="rgb(244, 44, 55)" />
<!-- iOS Safari -->
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

				<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
				<link rel="preload" as="style" href="//fonts.googleapis.com/css?family=Open+Sans&display=swap" />
				<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans&display=swap" media="all" />
				<meta name="generator" content="Elementor 3.24.4; features: additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-auto">

<!-- Meta Pixel Code -->
<script type='text/javascript'>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
</script>
<!-- End Meta Pixel Code -->
<script type='text/javascript'>
  fbq('init', '1480964285602159', {}, {
    "agent": "wordpress-6.6.2-3.0.7"
});
  </script><script type='text/javascript'>
  fbq('track', 'PageView', []);
  </script>
<!-- Meta Pixel Code -->
<noscript>
<img height="1" width="1" style="display:none" alt="fbpx"
src="https://www.facebook.com/tr?id=1480964285602159&ev=PageView&noscript=1" />
</noscript>
<!-- End Meta Pixel Code -->
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
						            <style>
				            
					div[id*='ajaxsearchlitesettings'].searchsettings .asl_option_inner label {
						font-size: 0px !important;
						color: rgba(0, 0, 0, 0);
					}
					div[id*='ajaxsearchlitesettings'].searchsettings .asl_option_inner label:after {
						font-size: 11px !important;
						position: absolute;
						top: 0;
						left: 0;
						z-index: 1;
					}
					.asl_w_container {
						width: 100;
						margin: 0px 0px 0px 0px;
						min-width: 200px;
					}
					div[id*='ajaxsearchlite'].asl_m {
						width: 100%;
					}
					div[id*='ajaxsearchliteres'].wpdreams_asl_results div.resdrg span.highlighted {
						font-weight: bold;
						color: rgba(217, 49, 43, 1);
						background-color: rgba(238, 238, 238, 1);
					}
					div[id*='ajaxsearchliteres'].wpdreams_asl_results .results img.asl_image {
						width: 70px;
						height: 70px;
						object-fit: cover;
					}
					div.asl_r .results {
						max-height: none;
					}
				
							.asl_w, .asl_w * {font-family:"roboto" !important;}
							.asl_m input[type=search]::placeholder{font-family:"roboto" !important;}
							.asl_m input[type=search]::-webkit-input-placeholder{font-family:"roboto" !important;}
							.asl_m input[type=search]::-moz-placeholder{font-family:"roboto" !important;}
							.asl_m input[type=search]:-ms-input-placeholder{font-family:"roboto" !important;}
						
						.asl_m, .asl_m .probox {
							background-color: rgb(253, 253, 253) !important;
							background-image: none !important;
							-webkit-background-image: none !important;
							-ms-background-image: none !important;
						}
					
						.asl_m .probox svg {
							fill: rgba(121, 69, 102, 1) !important;
						}
						.asl_m .probox .innericon {
							background-color: rgb(253, 253, 253) !important;
							background-image: none !important;
							-webkit-background-image: none !important;
							-ms-background-image: none !important;
						}
					
						div.asl_m.asl_w {
							border:1px none rgba(180, 96, 149, 1) !important;border-radius:20px 20px 20px 20px !important;
							box-shadow: none !important;
						}
						div.asl_m.asl_w .probox {border: none !important;}
					
						div.asl_r.asl_w.vertical .results .item::after {
							display: block;
							position: absolute;
							bottom: 0;
							content: '';
							height: 1px;
							width: 100%;
							background: #D8D8D8;
						}
						div.asl_r.asl_w.vertical .results .item.asl_last_item::after {
							display: none;
						}
								            </style>
			            <link rel="icon" href="https://agladiadoraturismo.com/wp-content/uploads/2022/01/cropped-logo-e-nome-logo-site-retina-1-32x32.png" sizes="32x32" />
<link rel="icon" href="https://agladiadoraturismo.com/wp-content/uploads/2022/01/cropped-logo-e-nome-logo-site-retina-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://agladiadoraturismo.com/wp-content/uploads/2022/01/cropped-logo-e-nome-logo-site-retina-1-180x180.png" />
<meta name="msapplication-TileImage" content="https://agladiadoraturismo.com/wp-content/uploads/2022/01/cropped-logo-e-nome-logo-site-retina-1-270x270.png" />
		<style type="text/css" id="wp-custom-css">
			/* Shop Page  */
.post-type-archive .page-title-section  .page-header .aux-container{
   text-align: center;
}
@media screen and (max-width: 503px){
.post-type-archive .aux-main .aux-wrapper .aux-container .aux-primary .content .products .product, .single-product .aux-main .aux-wrapper .aux-container .aux-primary .content .products .product{
    width: 100%;
}
}

.page-title-section .aux-breadcrumbs{
	 margin-bottom:10px;
}
.page-title-section .page-header{
	 border-bottom:none;
background: rgb(226,226,226);
background: linear-gradient(94deg, var(--e-global-color-accent) 52%, var(--e-global-color-d8899ec) 89%);
}

.aux-shop-archive .aux-sidebar .sidebar-inner .sidebar-content .searchform input[type="text"]{
   background: rgb(226,226,226);
background: linear-gradient(94deg, var(--e-global-color-accent) 52%, var(--e-global-color-d8899ec) 89%);
   border-radius: 30px;
   border: none;	
	 position:relative;
	 max-width:100%;
		padding:20px 28px;
	
}
.searchform input[type="text"]::-moz-placeholder{
	 font-weight:400;
	 line-height:19px;	 
	 font-size:16px;
  color:rgba(0,0,0,0.40)!important;

}
.searchform input[type="text"]::-webkit-input-placeholder{
	 font-weight:400;
	 line-height:19px;	 
	 font-size:16px;
  color:rgba(0,0,0,0.40)!important;
}
.aux-sidebar-style-border.left-sidebar .aux-sidebar-primary{
	 border:none;
	 margin-top: 20px;
		
}
.aux-shop-archive .aux-sidebar .sidebar-inner .sidebar-content .searchform:after{
	 content: "\e1d0";
   font-size: 20px;
   position: absolute;
   font-family: "auxin-front" !important;
   font-style: normal !important;
   font-weight: normal !important;
   font-variant: normal !important;
   text-transform: none !important;
   speak: none;
   line-height: 1;
    -webkit-font-smoothing: antialiased;
   right: 36px;
   top: 57px;
   background-color: var(--e-global-color-primary);
   color: #fff;
   padding: 12px;
   border-radius: 25px;
	 box-shadow: 0 5px 25px rgba(244,44,55,0.40);
}
.aux-shop-archive .aux-wrapper .aux-container .aux-primary .woocommerce-ordering .orderby{
   background-color:var(--e-global-color-871c65e);
   border-radius: 38px;
   border: none;
	 padding: 16px 0px 16px 29px;
}
@media (max-width: 498px){
.aux-shop-archive .aux-wrapper .aux-container .aux-primary .woocommerce-ordering .orderby {
      font-size: 12px;
}.aux-shop-archive .aux-wrapper .aux-container .aux-primary .woocommerce-result-count{
font-weight: 400;
}
	.aux-shop-archive .aux-wrapper .aux-container .aux-primary .woocommerce-ordering:after{
left: 193px;
    right: auto;
}
.aux-shop-archive .aux-wrapper .aux-container .aux-primary .woocommerce-ordering{
    width: 100%;
    margin: 0!important;
    margin-bottom: 28px!important;
}
}
.widget-container.aux-toggle-widget.aux-open .widget-title:after{
    top: 11px!important;
   transform: rotate(-90deg)!important;
}
.aux-shop-archive .aux-wrapper .aux-container .aux-primary .woocommerce-ordering .orderby{
   font-family: Montserrat;
   font-size: 15px;
   font-weight: 500;
   color: #fff;
	 background-image:none!important;

}
.aux-shop-archive .aux-wrapper .aux-container .aux-primary .woocommerce-ordering{
	 position:relative;
	 margin-top: -38px;
   margin-bottom: 55px;
}
.aux-shop-archive .aux-wrapper .aux-container .aux-primary .woocommerce-ordering:after{
left: 193px;
    right: auto;
}
.aux-shop-archive .aux-wrapper .aux-container .aux-primary .woocommerce-ordering:after{
   content: "\e1e9"!important;
   color: #fff;
   position: absolute;
   right: 20px;
   top: 21px;
   font-size: 12px;
   font-family: "auxin-front" !important;
   font-style: normal !important;
   font-weight: normal !important;
   font-variant: normal !important;
   text-transform: none !important;
   speak: none;
   line-height: 1;
    -webkit-font-smoothing: antialiased;
}
.aux-shop-archive .aux-wrapper .aux-container .aux-primary .woocommerce-result-count{
padding-top: 9px;
   font-size: 16px;
   font-weight: 400;
   line-height: 23px;
   color: var(--e-global-color-text);
}
.aux-shop-archive .products .product .woocommerce-loop-product__title {
   font-size: 17px;
   font-weight: 400;
   line-height: 23px;
   color: var(--e-global-color-text);
	 padding-top: 4px;
	 letter-spacing:-0.51px;
	 transition: all .2s cubic-bezier(.4,0,.2,1) 70ms;
}
.aux-shop-archive .product:hover   .woocommerce-loop-product__title{
	 color:var(--e-global-color-primary)!important;
	 font-weight:bold;
	 transition: all .2s cubic-bezier(.4,0,.2,1) 70ms;
}
.aux-shop-archive .products .product .price ins .woocommerce-Price-amount, .aux-shop-archive .products .product .price  .woocommerce-Price-amount {
   font-size: 20px;
   font-weight: bold;
   line-height: 24px;
   color: var(--e-global-color-text);
	 letter-spacing:-0.6px;
}
.aux-shop-archive .products .product .price del .woocommerce-Price-amount, .woocommerce ul.products li.product .price{
	 font-size: 16px;
   font-weight: 500;
   line-height: 24px;
   color: var(--e-global-color-secondary);
	 letter-spacing:-0.48px;	  
	 transition: transform 1.2s cubic-bezier(.19,1,.22,1) 70ms !important;	 
}
.aux-shop-archive .products .product .price .woocommerce-Price-amount .woocommerce-Price-currencySymbol{
	 padding-right: 5px;
}
.aux-shop-archive .products .product .price{
	 padding-top:7px;
}
.aux-shop-archive a.button, .aux-shop-archive a.button:hover{
   background-color: var(--e-global-color-primary);
   border-radius: 25px;
   font-size: 15px;
   font-weight: 400;
   line-height: 19px;
   color: #fff;
   letter-spacing: -0.45px;
   text-transform: capitalize;
   padding: 9px 25px;
}
.aux-shop-archive a.button:not(.product_type_variable){
   position: absolute;
   bottom: 0;
   left: -158px;
}

.aux-shop-archive a.button.added:not(.product_type_variable) {
	left: -181px;
}
.aux-shop-archive a.button.product_type_variable {
	bottom: 10px;
}
.single-product a.button.product_type_variable{
   bottom: 10px;
   left: -175px;
}
.aux-shop-archive .product:hover  .price{
   transform: translateX(calc(34% + 30px)) !important;
   transition: transform 1.2s cubic-bezier(.19,1,.22,1) 70ms !important;
}
.aux-shop-archive .product:hover  .button {
   transform: translateX(calc(97% + 30px)) !important;
   transition: transform 1.2s cubic-bezier(.19,1,.22,1) 70ms !important;
}
.aux-shop-archive .aux-wrapper .aux-container .product{	
   position: relative;
   overflow: hidden;
}
.aux-shop-archive .aux-wrapper .aux-container .aux-primary .content .product img {
   border-radius: 20px;
}
.aux-shop-archive ul.products li.product .onsale{
   top: 21px;
   right: auto;
   left: 16px;
   width: 48px;
   background-color: var(--e-global-color-primary);
   font-size: 13px;
   font-weight: bold;
}
.aux-shop-archive .aux-sidebar .sidebar-inner .widget_product_categories .product-categories .cat-item a{
	 font-size: 16px;
   font-weight: 400;
   line-height: 23px;
   color: rgba(0,0,0,0.60);
	 letter-spacing:-0.48px;	
	 text-decoration: none;
	 transition: all .2s cubic-bezier(.4,0,.2,1) 70ms;
	  margin-left: 43px;
}
.aux-shop-archive .aux-sidebar .sidebar-inner .widget_product_categories .product-categories .cat-item a:hover, .aux-shop-archive .aux-sidebar .sidebar-inner .widget_product_categories .product-categories .current-cat a{
	 color:var(--e-global-color-primary);
	 font-weight:bold;
	 transition: all .2s cubic-bezier(.4,0,.2,1) 70ms;
}
@media screen and (max-width: 479px){
.aux-resp .widget-title {
    text-align: left;
}
}
.aux-shop-archive .aux-sidebar .sidebar-inner .widget_product_categories .product-categories .cat-item{
	 margin-top:10px;
}
.aux-shop-archive .aux-sidebar .widget-title{
	 border-bottom:none;
	 margin-bottom: 0;
}
.widget-container.aux-toggle-widget .widget-title:after{
   content: "\e1e9"!important;
   color: var(--e-global-color-text);
   font-size: 18px;
	 right: 12px;
   font-family: "auxin-front" !important;
   font-style: normal !important;
   font-weight: normal !important;
   font-variant: normal !important;
   text-transform: none !important;
  speak: none;
  line-height: 1;
    -webkit-font-smoothing: antialiased;
	background-image:none;
}
.aux-shop-archive .price_slider_wrapper{
	padding-top: 14px;
}
.aux-shop-archive  .widget_price_filter .ui-slider .ui-slider-range{
	background-color:var(--e-global-color-primary);
	height: 5px;
}
.aux-shop-archive .widget_price_filter .price_slider_wrapper .ui-widget-content{
	 background-color: #F3F3F3;	
		height: 4px;
}
.aux-shop-archive .widget_price_filter .ui-slider .ui-slider-handle:nth-child(3){
	background-color:var(--e-global-color-primary);	
}
.aux-shop-archive .widget_price_filter .ui-slider .ui-slider-handle:nth-child(2){
	background-color:var(--e-global-color-text);	
}
.aux-shop-archive .widget_price_filter .price_slider_amount .button{
    width: 100%;
    background-color: var(--e-global-color-text);
    padding: 16px;
    border-radius: 25px;
    color: #fff;
    font-size: 16px;
    font-weight: 500;
    line-height: 19px;
    letter-spacing: -0.48px;
	  margin-top: 40px;
}
.aux-shop-archive  .price_slider_amount{
    padding-top: 14px;
    display: flex;
    flex-direction: column-reverse;
	margin-top:-10px;
}
.aux-shop-archive  .price_label{
	color:#fff;
}
.aux-shop-archive  .price_label span{
	color:var(--e-global-color-text);
	font-size:15px;
	font-weight:500;
	line-height:19px;
	letter-spacing:-0.45px;
}
.aux-shop-archive .price_label .from{
    float: left;	
}
.aux-shop-archive .aux-sidebar-primary{   
  width:30%;
}
.aux-shop-archive .aux-wrapper .aux-primary{
	width: 92%;
}
.left-sidebar .aux-primary{
	padding-left: 4px;
}
@media screen and (max-width: 1382px){
.aux-shop-archive .aux-sidebar-primary{
  width: 34%;
}
}
@media screen and (max-width: 1171px){
.aux-shop-archive .aux-sidebar-primary{
   width: 40%;
}
	}
@media screen and (max-width: 862px){
.aux-shop-archive .aux-sidebar-primary{
   width: 47%;
}
}
@media screen and (max-width: 1004px){
	.aux-shop-archive .widget-title{
	 font-size:16px!important;
		}
}
@media screen and (max-width: 767px){
.aux-shop-archive .aux-wrapper .aux-primary{
   width: 100%;
}
.aux-shop-archive .aux-sidebar .sidebar-inner .sidebar-content .searchform:after{
   right: 8px;
   top: 87px;
}
}
@media screen and (max-width: 1004px)and (min-width: 767px){
.aux-shop-archive .products .product .woocommerce-loop-product__title{
		font-size:13px!important;
	}
}
.aux-shop-archive .widget_price_filter{
	 margin-top: 32px;
   border-top: 1px solid var(--e-global-color-secondary);
	 padding-top: 39px;
}
@media screen and (max-width: 1474px) and (min-width: 1336px){
.aux-shop-archive .product:hover .price{
   transform: translateX(calc(40% + 30px));
}
}
@media screen and (max-width: 1336px) {
.aux-shop-archive a.button, .single-product a.button{
   position: relative;
}
.aux-shop-archive ul.products li.product .price{
   transform: none;
   transition: none;
}
.aux-shop-archive a.button{
   font-size: 12px;
}
.aux-shop-archive .product:hover .button{
    transform: translateX(calc(100% + 48px));
}
.aux-shop-archive .products .product .price del .woocommerce-Price-amount, .woocommerce ul.products li.product .price{
    font-size: 14px;
}
.aux-shop-archive .products .product .price ins .woocommerce-Price-amount, .aux-shop-archive .products .product .price .woocommerce-Price-amount{
    font-size: 18px;
}
.aux-shop-archive .aux-wrapper .aux-container .product{
    margin-bottom: 14px;
}
.aux-shop-archive .widget_price_filter{
	 margin-top: 5px;
	 padding-top: 26px;
}
}
.aux-shop-archive .woocommerce-pagination .page-numbers .current{
  color: #fff;
	font-weight:700;
	font-size:18px;
	padding: 10px 12px;
  border-radius: 9px;
background: rgb(244,44,55);
background: -moz-linear-gradient(356deg, rgba(244,44,55,1) 40%, rgba(220,40,50,1) 73%);
background: -webkit-linear-gradient(356deg, rgba(244,44,55,1) 40%, rgba(220,40,50,1) 73%);
background: linear-gradient(356deg, rgba(244,44,55,1) 40%, rgba(220,40,50,1) 73%);
filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#f42c37",endColorstr="#dc2832",GradientType=1);
    border-color: #F42C37;
}
.aux-shop-archive .woocommerce-pagination .page-numbers li a{
	font-weight:700;
	font-size:18px;
	color:var(--e-global-color-text);
}
.aux-shop-archive .woocommerce-pagination{
  text-align: left!important;	
}
.aux-shop-archive  .page-numbers, .aux-shop-archive .woocommerce-pagination ul li{
	border:none!important;
	margin-right: 11px!important;
}

.aux-shop-archive .aux-wrapper .aux-container .aux-primary .content{
padding-bottom: 90px;
}
/* Single Post */
.single-post .aux-wrapper .aux-container .aux-primary{
	padding-top:64px;
}
.single-post .content .aux-medium-context  .entry-main .entry-header{
	display:none;
}
.single-post  .aux-wrapper .aux-medium-context .entry-media .aux-media-image img{
    border-radius: 20px;
}
.single-post .aux-container .aux-primary .content .aux-medium-context .entry-main .entry-info  .entry-author .meta-sep{
	color:var(--e-global-color-text);
}
.single-post .content .aux-medium-context .entry-media{
	margin-bottom: 35px;
}
.single-post textarea{
	 background-color: #EFEFEF;
   border: none;
   border-radius: 25px;
   padding: 29px 0 28px 39px!important;
	margin-top:25px;
	
}
.single-post input[type=email], .single-post .aux-wrapper .aux-primary .content .comment-respond .comment-form  input[type=url]{
	background-color: #EFEFEF;
  border: none;
  border-radius: 25px;
  padding: 29px 0 28px 39px!important;
	margin-top:25px;
}
.single-post .aux-wrapper .aux-container .aux-primary .content .comment-respond{
  margin-left: 15%!important;
  margin-right:15%!important;
}
.single-post .aux-wrapper .aux-container .aux-primary .content .comment-respond .comment-reply-title{
   margin-bottom: 0;
}
.single-post .aux-wrapper .aux-container .aux-primary .content .comment-respond .aux-form-inline-two .aux-inline-inputs{
	flex-basis: calc(50% - 16px);
}

.aux-input-group textarea::-moz-placeholder, .aux-input-group input[type="email"]::-moz-placeholder, .aux-input-group input[type="url"]::-moz-placeholder {
	color:rgba(0,0,0,0.50);
	font-size:16px;
	font-weight:400;
	font-style:normal!important;


	
}
.single-product  .wpulike-heart{
    display:none;
}
@media screen and (min-width:504px) {
.single-product .woocommerce-Reviews .commentlist .aux-star-rating{
	position:absolute;
	right:0
}
}

.single-product .meta{
	margin:0!important;
}
.aux-wrapper  .aux-container .aux-primary .content .comment-respond.comment-respond{
	margin-top: 61px!important;
	
}
.aux-input-group textarea::-webkit-input-placeholder, .aux-input-group input[type="email"]::-webkit-input-placeholder, .aux-input-group input[type="url"]::-webkit-input-placeholder {
	color:rgba(0,0,0,0.50);
	font-size:16px;
	font-weight:400;
	line-height:19px;
	font-style:normal!important;	
}
.aux-input-group textarea:focus::-webkit-input-placeholder,  .aux-input-group input[type="email"]:focus::-webkit-input-placeholder, .aux-input-group input[type="url"]:focus::-webkit-input-placeholder{
	font-weight:bold;
	color:var(--e-global-color-text);
}
.single-post .form-submit .submit{
	background: var(--e-global-color-primary);
	border-radius:25px;
	padding:16px 70px!important;	 
}
.single-post .form-submit .submit:hover{
	background-color:var(--e-global-color-text);
}
.single-post .form-submit {
	margin-right: 0;
  margin-left: auto;
}
.single-post .comment-form-cookies-consent{
	display:none;
}
.single-post textarea{
	margin-top:0!important;
}
@media screen and (max-width: 664px){
.single-post .aux-wrapper .aux-container .aux-primary .content .aux-medium-context .entry-main .entry-content, 
.single-post .aux-wrapper .aux-container .aux-primary .content .comment-respond{
    margin-left: 0%!important;
    margin-right: 0%!important;
	}
}
/* Single-Product */
.single-product .product .entry-summary .entry-title{
  font-weight: bold;
  font-size: 40px;
  color: var(--e-global-color-text);
  letter-spacing: -1.2px;
	margin-bottom: 22px!important;
  line-height: 56px;
}
.single-product .aux-rating-box.aux-star-rating .aux-star-rating-avg:before{
  color:#F83E3E;
}
.single-product .aux-rating-box.aux-star-rating {
	font-size: 20px;
}
.single-product .aux-rating-box.aux-star-rating:before{
   color:var(--e-global-color-secondary);
}
.single-product .entry-summary .woocommerce-product-rating .woocommerce-review-link{
	font-weight: 500;
  font-size: 14px;
  color: #9F9F9F;
  letter-spacing: -0.7px;
  line-height: 18px;
	margin-left:10px;
}
.single-product .entry-summary .price .woocommerce-Price-amount {
	font-weight: bold;
  font-size: 35px!important;
  color:var(--e-global-color-text);
  letter-spacing: -1.05px;
  line-height: 43px;
	margin-left:10px;
}
.single-product .entry-summary .price .woocommerce-Price-currencySymbol{
	margin-right:8px;
}
.single-product .aux-wrapper .aux-primary .product .entry-summary .woocommerce-product-details__short-description  p{ 
  height: 137px;
  color: rgba(0,0,0,0.60);
  font-size: 15px;
  line-height: 23px;
  max-width: 375px;
  font-weight: 400;
  overflow: hidden;
	margin-top: 35px;
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product .entry-summary .cart{
margin-top: 59px;
	margin-bottom:55px		
}
.single-product  .tagged_as{
	display:none;
}
.single-product  .aux-wrapper .aux-container .aux-primary .content  .product .entry-summary .quantity .qty{   width: 82px;
text-align: center;
border-radius: 25px;
border: 1px solid
var(--e-global-color-text);
font-size: 20px;
font-weight: bold;
line-height: 38px;
color:
var(--e-global-color-text);
padding: 4px 16px 4px 10px;
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product .entry-summary .cart .button {    width: 188px;
  background-color: var(--e-global-color-primary);
  border-radius: 25px;
  padding: 16px 36px;
  color: #fff;
  font-weight: 400;
  line-height: 19px;
  letter-spacing: -0.48px;
	margin-left: 12px;
	
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product .entry-summary .cart .button:hover{
	background-color:var(--e-global-color-text)!important;
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product .entry-summary  .product_meta .posted_in, .single-product .aux-wrapper .aux-container .aux-primary .content .product .entry-summary  .product_meta .posted_in a{
	 font-weight: 400;
   font-size:16px;
   color:var(--e-global-color-text);
   line-height: 19px;
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product .entry-summary  .product_meta .posted_in a{
	color:var(--e-global-color-primary);
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product .entry-summary {
  width: 35%;
	margin-top:5%;	
}
.single-product .aux-wrapper .aux-container  .images{
 width: 59%;
	padding-bottom:60px
}
.single-product .product .woocommerce-tabs .tabs::before{
  top: 0;
	bottom:auto!important;
	z-index:5!important;	
}
.single-product  .product .woocommerce-tabs .tabs li{
	border:none!important;
	z-index:0;
	background-color:transparent!important;
	margin-left:78px!important;
}
@media screen and (max-width: 1123px){
.single-product  .product .woocommerce-tabs .tabs li{
margin-left:0!important;
}
}
.single-product  .product .woocommerce-tabs .tabs{
	text-align:center;
	

}
.single-product  .product .woocommerce-tabs .tabs .active {
  color: var(--e-global-color-text);
  font-weight: bold;
  font-size: 16px;
  line-height: 25px;

}
.single-product  .product .woocommerce-tabs .tabs .active a{
	 border-top: 4px solid var(--e-global-color-primary);
}
.single-product  .product .woocommerce-tabs .tabs .description_tab a, .single-product  .product .woocommerce-tabs .tabs .reviews_tab a{
	color:var(--e-global-color-secondary);
	padding-top:20px;
	
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product  .panel{
padding: 3% 15%!important;
	
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product  .panel h2{
  font-weight: bold;
  color: var(--e-global-color-text);
  font-size: 25px;
  line-height: 23px;
  letter-spacing: -0.75px;
  padding-bottom: 22px;
  padding-top: 15px;
	
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product  .panel p{
	  font-weight: 400;
    font-size: 15px;
    line-height: 25px;
    color: rgba(0,0,0,0.60);

}
.single-product .aux-wrapper .aux-container  .woocommerce-product-gallery__image{
	border-radius:20px;
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product .related>h2{
	text-align:center;
	 font-weight: bold;
   color: var(--e-global-color-text);
   font-size:45px;
   line-height: 68px;
   letter-spacing: -2.25px;
   padding-bottom: 52px;
   padding-top: 15px;
}
.single-product .aux-wrapper .aux-container .product .woocommerce-LoopProduct-link .woocommerce-loop-product__title{
  font-weight: 400;
  color: var(--e-global-color-text);
  font-size:17px;
  line-height: 23px;
  letter-spacing: -0.51px;
  padding-top: 5px;
  padding-bottom:12px;
	 transition: all .2s cubic-bezier(0.4, 0, 0.2, 1) 70ms;
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product li:hover  .woocommerce-loop-product__title{
	color:red;
	font-weight:bold;
	transition: all .2s cubic-bezier(0.4, 0, 0.2, 1) 70ms;
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product img{
	border-radius:20px;
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product .price ins .woocommerce-Price-amount, .single-product .aux-wrapper .aux-container .aux-primary .content .product  .price  .woocommerce-Price-amount{
	font-weight:bold;
	color:var(--e-global-color-text);
	font-size:20px;
	line-height:24px;
	letter-spacing:0.6px;
	margin-top:50px;

}
.single-product .aux-wrapper .aux-container .aux-primary .content .product del .woocommerce-Price-amount{
	color:var(--e-global-color-secondary)!important;
	font-size:16px!important;
	font-weight:400!important;
}
.single-product .aux-wrapper .aux-container .aux-primary .content .products .aux-rating-box.aux-star-rating, .aux-shop-archive .aux-rating-box.aux-star-rating{
	display:none;
}
.single-product li:hover .button{
	transform: translateX(calc(97% + 30px));
    transition: transform 1.2s cubic-bezier(.19,1,.22,1) 70ms;
}
.single-product a.button:not(.product_type_variable){
	position: absolute;
  bottom: 0;
  left: -158px;
}
.single-product .aux-wrapper .aux-container .product{
	position: relative;
  overflow: hidden;
}
.single-product .products .product .price del .woocommerce-Price-amount{
	 transition: transform 1.2s cubic-bezier(.19,1,.22,1) 70ms;
}
.single-product li:hover .price{
	transform: translateX(calc(34% + 30px));
    transition: transform 1.2s cubic-bezier(.19,1,.22,1) 70ms;
}
.single-product a.button{
	background-color: var(--e-global-color-primary);
  border-radius: 25px;
  font-size: 15px;
  font-weight: 400;
  line-height: 19px;
  color: #fff;
  letter-spacing: -0.45px;
  text-transform: capitalize;
  padding: 9px 25px;
}
.single-product  .products .product .onsale, .single-product span.onsale{
	top: 21px!important;
  right: auto!important;
  left: 16px!important;
  width: 48px;
  background-color: var(--e-global-color-primary);
  font-size: 13px;
  font-weight: bold;	
}

@media screen and (max-width: 1336px) {
.single-product a.button{
   position: relative;
}
.single-product  .products li.product .price{
  transform: none;
  transition: none;
}

.single-product li:hover .button{
  transform: translateX(calc(100% + 30px));
}
.single-product .aux-wrapper .aux-container .product .woocommerce-LoopProduct-link .woocommerce-loop-product__title{
  font-size: 14px;
}
}
.single-product   .product  .woocommerce-Tabs-panel .woocommerce-Reviews .comment-respond .comment-reply-title{
  font-size: 20px;
  font-weight: bold;
  color: var(--e-global-color-text)!important;
  line-height: 30px;
  letter-spacing: -0.6px;
}
.single-product  .woocommerce-tabs .woocommerce-Reviews .comment-respond .comment-form .comment-form-rating label{    
  font-weight: bold;
  color: var(--e-global-color-text);
  font-size: 16px;
  line-height: 23px;
  padding-right: 25px;
}
.single-product .comment-form-comment label{
  font-weight: 400;
  color : rgba(0,0,0,0.50);
  font-size: 16px;
  line-height: 19px;  
}
.single-product .entry-content .woocommerce-Reviews .comment-respond .comment-form .comment-form-rating{
  display: flex;
  margin-top: 17px;
}

.single-product .woocommerce-Tabs-panel  .woocommerce-Reviews .comment-respond .customize-unpreviewable .comment-form-rating .stars{
padding-top:6px!important;
}
.single-product .stars a::before{
	color:#F83E3E;
}

.aux-cart-element-container .aux-cart-wrapper .aux-card-dropdown{
  z-index: 6;
  right: 1px;
  left: auto;
  border-radius: 20px;
  border: none;
  box-shadow: 0 3px 40px #0000001A;
  background-color: #fff;
	width:365px;
}
.aux-cart-element-container .aux-card-dropdown .aux-card-box .aux-card-item .aux-card-item-img img{
 border-radius: 15px;
  width: 100px;
  height: 95px;
}
.aux-card-dropdown .aux-card-box .aux-card-item .aux-card-item-details h3{
  font-weight: 400;
  font-size: 15px;
  line-height: 23px;
  color: var(--e-global-color-text);
  letter-spacing: -0.45px;
	padding-bottom:15px;
	padding-top:10px;
}
.single-product .aux-container .aux-primary .content .product .wc-tabs-wrapper .entry-content .woocommerce-Reviews .comment-respond .comment-form .comment-form-comment textarea, .single-product .aux-container .aux-primary .content .product .wc-tabs-wrapper .entry-content .woocommerce-Reviews .comment-respond  input[type=email], .single-product .aux-container .aux-primary .content .product .wc-tabs-wrapper .entry-content .woocommerce-Reviews .comment-respond input[type=text]{
    background-color:#EFEFEF!important;
   border: none;
   border-radius: 50px;
	 padding: 26px!important;
}
.single-product .aux-container .aux-primary .content .product .wc-tabs-wrapper .entry-content .woocommerce-Reviews .comment-respond .comment-form .comment-form-comment textarea{
	border-radius:25px;
    height: 271px!important;
}

.single-product .woocommerce-Reviews .comment-respond .comment-form .comment-form-author, .single-product .woocommerce-Reviews .comment-respond .comment-form .comment-form-email{
   display: inline-block;
   width: 47%; 
}
.single-product .woocommerce-Tabs-panel .woocommerce-Reviews .comment-respond .comment-form .comment-form-cookies-consent{
	display:none;
}
.single-product .woocommerce-Reviews .comment-respond .comment-form .comment-form-email{
	  margin-left: 4%!important;
}
.single-product .aux-container .aux-primary .content .product .wc-tabs-wrapper .entry-content .woocommerce-Reviews .comment-respond  input[type=email], .single-product .aux-container .aux-primary .content .product .wc-tabs-wrapper .entry-content .woocommerce-Reviews .comment-respond input[type=text]{
	width: 100%!important;
}
.aux-card-dropdown .aux-card-box .aux-card-item .aux-card-item-details span{
  font-weight: bold;
  font-size: 18px;
  line-height: 22px;
  color: var(--e-global-color-text);
	letter-spacing:-0.45px;
}
.aux-cart-wrapper .aux-card-box{
	border:none;
}
.aux-cart-wrapper .aux-card-item:last-child{
	border-bottom: 1px solid var(--e-global-color-secondary);
    padding-bottom: 25px;
}
.aux-cart-wrapper .aux-card-checkout{
	 padding: 12px 1.25em 1.25em;
}
.aux-cart-wrapper .aux-card-checkout .aux-card-final-amount .aux-card-final-amount-text{	
  font-weight: bold;
  font-size: 14px;
  color: var(--e-global-color-text);
  text-transform: capitalize;
  padding-bottom: 0;
}
.aux-cart-wrapper .aux-card-checkout .aux-card-final-amount .woocommerce-Price-amount{
  font-weight: bold;
  font-size: 20px;
  color: #F83E3E;
  letter-spacing: -0.6px;
}
.aux-cart-wrapper .aux-card-checkout .aux-button{
  margin-top: 23px;
  background-color: var(--e-global-color-text);
  border-radius: 25px;
  font-weight: 500;
  font-size: 15px;
  text-transform: capitalize;
  line-height: 23px;
	padding: 15px 78px;
}
.aux-cart-wrapper .aux-card-checkout .aux-button:last-child{
	 margin-bottom: 8px;
	 margin-top: -10px;
   background-color: var(--e-global-color-primary)!important;
  color: #fff;
  box-shadow: none;
  font-weight: 500;
   line-height: 19px;
}
.aux-black.aux-button.aux-outline .aux-overlay:after, .aux-button.aux-black .aux-overlay:after{
	background-color:var(--e-global-color-text)!important;
	
}
.single-product .wc-tabs-wrapper .woocommerce-Reviews .comment-respond .form-submit input{
  background-color: #F42C37!important;
  color: #fff!important;
  border-radius: 25px!important;
  font-weight: 500!important;
  font-size: 16px!important;
  letter-spacing: -0.48px!important;
  line-height: 19px!important;
  padding: 16px 73px!important;
}
.single-product .wc-tabs-wrapper .woocommerce-Reviews .comment-respond .form-submit input:hover{
	background-color:var(--e-global-color-text)!important;
}
.single-product .form-submit{
	text-align:right;	
}
.single-product .comment-form-author{
	padding-top:72px!important;	
}
.single-product .comment-form{
	position:relative;
}
.single-product .comment-form-rating{
	position:absolute;
	top:24px;	
}
.single-product .woocommerce-message{
	display:none;
}
@media screen and (max-width: 937px){.single-product .aux-wrapper .aux-container .aux-primary .content .product .entry-summary{
  width: 100%;
}
.single-product .aux-wrapper .aux-primary .product .entry-summary .woocommerce-product-details__short-description p{
  max-width: 95%;
}
.single-product .product .images.woocommerce-product-gallery{
   width: 100%;
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product .panel{
		padding-left:0!important;
		padding-right:0!important;
	}
}
@media screen and (max-width: 694px){
.single-product a.button{
     font-size: 12px;
}
.single-product li:hover .button{
      transform: translateX(calc(100% + 76px));
}
.single-product .aux-wrapper .aux-container .aux-primary .content .product .related>h2{
	font-size: 31px;
    line-height: 55px;
    letter-spacing: -1.25px;	
	}
.single-product a.button{
		padding:5px 10px;
	}
.single-product .entry-content .woocommerce-Reviews .comment-respond .comment-form .comment-form-rating{

  margin-top: 65px;
}
}
.single-product .product .woocommerce-tabs .tabs li.active::before, .single-product .product .woocommerce-tabs .tabs .active::after, .single-product .product .woocommerce-tabs .tabs li::before, .single-product .product .woocommerce-tabs .tabs li::after{
	display:none;
}
.single-product .comment_container img{
    width: 58px!important;
	border-radius:100px!important;
}

.single-product .woocommerce-Price-amount{
	margin-left:0!important;	
}
.single-product .aux-wrapper .aux-container  .aux-primary .content .product .woocommerce-tabs  .woocommerce-Reviews .commentlist .comment_container .comment-text{
	border:none!important;
	padding:0!important;
	padding-left:25px!important;
}
.single-product .aux-wrapper .aux-container  .aux-primary .content .product .woocommerce-tabs  .woocommerce-Reviews .commentlist{
	    background-color: #EFEFEF!important;
    padding: 59px 50px 35px 50px;
    border-radius: 25px;
}
.single-product .aux-wrapper .aux-container  .aux-primary .content .product .woocommerce-tabs .woocommerce-Reviews .woocommerce-Reviews-title{
    color: #000;
    font-size: 24px;
    font-weight: 600;
    letter-spacing: -.3px;
    padding-bottom: 58px;
}
.single-product  .woocommerce-review__author, .single-product  .woocommerce-review__published-date{
color: var(--e-global-color-text);
}

#wpadminbar + #inner-body .comment-form-rating {
	position: static;
}		</style>
		<!-- end wp_head -->
</head>


<body class="error404 wp-custom-logo theme-phlox woocommerce-no-js elementor-default elementor-kit-2113 phlox aux-dom-unready aux-full-width aux-resp aux-s-fhd  aux-page-animation-off _auxels"  data-framed="">

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NXJ8J83"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->    <script type='text/javascript'>

      function updateConfig() {
        var eventsFilter = "Microdata,SubscribedButtonClick";
        var eventsFilterList = eventsFilter.split(',');
        fbq.instance.pluginConfig.set("1480964285602159", 'openbridge',
          {'endpoints':
            [{
              'targetDomain': window.location.href,
              'endpoint': window.location.href + '.open-bridge'
            }],
            'eventsFilter': {
              'eventNames':eventsFilterList,
              'filteringMode':'blocklist'
            }
          }
        );
        fbq.instance.configLoaded("1480964285602159");
      }

      window.onload = function() {
        var s = document.createElement('script');
        s.setAttribute('src', "https://agladiadoraturismo.com/wp-content/plugins/official-facebook-pixel/core/../js/openbridge_plugin.js");
        s.setAttribute('onload', 'updateConfig()');
        document.body.appendChild( s );
      }
    </script>
<div id="inner-body">

		<div data-elementor-type="header" data-elementor-id="70" class="elementor elementor-70 elementor-location-header" data-elementor-post-type="elementor_library">
					<section class="elementor-section elementor-top-section elementor-element elementor-element-d9f9b02 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="d9f9b02" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="aux-parallax-section elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-9617791" data-id="9617791" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-d6a69a2 elementor-widget elementor-widget-image" data-id="d6a69a2" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img fetchpriority="high" width="270" height="210" src="https://agladiadoraturismo.com/wp-content/uploads/2019/10/logo-e-nome-logo-site-retina-1.png" class="attachment-large size-large wp-image-2655" alt="" />													</div>
				</div>
					</div>
		</div>
				<div class="aux-parallax-section elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-2aef2d6" data-id="2aef2d6" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-0909c47 elementor-align-right elementor-mobile-align-center elementor-hidden-desktop elementor-hidden-tablet elementor-invisible elementor-widget elementor-widget-button" data-id="0909c47" data-element_type="widget" data-settings="{&quot;_animation_mobile&quot;:&quot;fadeInUp&quot;,&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm elementor-animation-bounce-in" href="https://agladiadoraturismo.com/whatsapp-turismo">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-icon">
				<i aria-hidden="true" class="fab fa-whatsapp"></i>			</span>
									<span class="elementor-button-text">whatsapp - (43)98429-8337</span>
					</span>
					</a>
		</div>
				</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-edcaeed elementor-section-content-middle elementor-hidden-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="edcaeed" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="aux-parallax-section elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-8937c79" data-id="8937c79" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-84a13be elementor-align-center elementor-icon-list--layout-inline elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="84a13be" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items elementor-inline-items">
							<li class="elementor-icon-list-item elementor-inline-item">
											<a href="https://www.instagram.com/agladiadora.turismo">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fab fa-instagram"></i>						</span>
										<span class="elementor-icon-list-text">@agladiadora.turismo</span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<a href="https://www.facebook.com/agladiadora.turismo">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fab fa-facebook"></i>						</span>
										<span class="elementor-icon-list-text">@agladiadora.turismo</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
				<div class="aux-parallax-section elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-339be93" data-id="339be93" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-2a7ffa3 elementor-align-right elementor-mobile-align-center elementor-invisible elementor-widget elementor-widget-button" data-id="2a7ffa3" data-element_type="widget" data-settings="{&quot;_animation_mobile&quot;:&quot;fadeInUp&quot;,&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm elementor-animation-bounce-in" href="https://agladiadoraturismo.com/whatsapp-turismo">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-icon">
				<i aria-hidden="true" class="fab fa-whatsapp"></i>			</span>
									<span class="elementor-button-text">whatsapp - (43)98429-8337</span>
					</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<div class="elementor-element elementor-element-c63e02d elementor-widget elementor-widget-aux_menu_box" data-id="c63e02d" data-element_type="widget" data-widget_type="aux_menu_box.default">
				<div class="elementor-widget-container">
			<div class="aux-elementor-header-menu aux-nav-menu-element aux-nav-menu-element-c63e02d"><div class="aux-burger-box" data-target-panel="offcanvas" data-target-content=".elementor-element-c63e02d .aux-master-menu"><div class="aux-burger aux-lite-small"><span class="mid-line"></span></div></div><!-- start master menu -->
<nav id="master-menu-elementor-c63e02d" class="menu-main-menu-container">

	<ul id="menu-main-menu" class="aux-master-menu aux-no-js aux-skin-classic aux-with-indicator aux-with-splitter aux-horizontal" data-type="horizontal"  data-switch-type="toggle" data-switch-parent=".elementor-element-c63e02d .aux-offcanvas-menu .offcanvas-content" data-switch-width="768"  >
		<!-- start single menu -->
		<li id="menu-item-107" class="a1i0s0 menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-107 aux-menu-depth-0 aux-menu-root-1 aux-menu-item">
			<a href="https://agladiadoraturismo.com/" class="aux-item-content">
				<span class="aux-menu-label">Home</span>
			</a>
		</li>
		<!-- end single menu -->
		<!-- start single menu -->
		<li id="menu-item-3621" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3621 aux-menu-depth-0 aux-menu-root-2 aux-menu-item">
			<a href="https://agladiadoraturismo.com/buscar/" class="aux-item-content">
				<span class="aux-menu-label">Buscar</span>
			</a>
		</li>
		<!-- end single menu -->
		<!-- start single menu -->
		<li id="menu-item-3563" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3563 aux-menu-depth-0 aux-menu-root-3 aux-menu-item">
			<a href="https://agladiadoraturismo.com/catalogo/" class="aux-item-content">
				<span class="aux-menu-label">Catálogo</span>
			</a>
		</li>
		<!-- end single menu -->
		<!-- start single menu -->
		<li id="menu-item-659" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-659 aux-menu-depth-0 aux-menu-root-4 aux-menu-item">
			<a href="https://agladiadoraturismo.com/calendario/" class="aux-item-content">
				<span class="aux-menu-label">Calendário 2024</span>
			</a>
		</li>
		<!-- end single menu -->
		<!-- start single menu -->
		<li id="menu-item-4613" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4613 aux-menu-depth-0 aux-menu-root-5 aux-menu-item">
			<a href="https://agladiadoraturismo.com/calendario_2025/" class="aux-item-content">
				<span class="aux-menu-label">Calendário 2025</span>
			</a>
		</li>
		<!-- end single menu -->
		<!-- start single menu -->
		<li id="menu-item-109" class="a1i0s0 menu-item menu-item-type-post_type menu-item-object-page menu-item-109 aux-menu-depth-0 aux-menu-root-6 aux-menu-item">
			<a href="https://agladiadoraturismo.com/sobre/" class="aux-item-content">
				<span class="aux-menu-label">Sobre Nós</span>
			</a>
		</li>
		<!-- end single menu -->
		<!-- start single menu -->
		<li id="menu-item-111" class="a1i0s0 menu-item menu-item-type-post_type menu-item-object-page menu-item-111 aux-menu-depth-0 aux-menu-root-7 aux-menu-item">
			<a href="https://agladiadoraturismo.com/contato/" class="aux-item-content">
				<span class="aux-menu-label">Contato</span>
			</a>
		</li>
		<!-- end single menu -->
	</ul>

</nav>
<!-- end master menu -->
<section class="aux-offcanvas-menu aux-pin-right"><div class="aux-panel-close"><div class="aux-close aux-cross-symbol aux-thick-medium"></div></div><div class="offcanvas-header"></div><div class="offcanvas-content"></div><div class="offcanvas-footer"></div></section></div><style>@media only screen and (min-width: 769px) { .elementor-element-c63e02d .aux-burger-box { display: none } }</style>		</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
		
    <main id="main" class="aux-main aux-territory  no-sidebar aux-user-entry" >
        <div class="aux-wrapper">
            <div class="aux-container aux-fold">

                <div id="primary" class="aux-primary" >
                    <div class="content" role="main" data-target="index" >

                                                <article class="post error404 not-found" >

                            <div class="entry-main">

                                <div class="entry-content">
                                    <h2>404</h2>
                                    <div class="aux-404-icon"></div>
                                    <h3 class="entry-title">Oops! Page Not Found</h3>
                                    <p class="message404" >It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.</p>
                                </div>

                                    <div  class="aux-search-section aux-404-search">
            <button class="aux-search-icon  auxicon-search-4  "></button>
                <div  class="aux-search-form aux-iconic-search">
            <form action="https://agladiadoraturismo.com/" method="get" >
            <div class="aux-search-input-form">
                            <input type="text" class="aux-search-field"  placeholder="Search..." name="s" autocomplete="off" />
                                    </div>
                            <div class="aux-submit-icon-container auxicon-search-4 ">
                    <input type="submit" class="aux-iconic-search-submit" value="Search" >
                </div>
                        </form>
        </div><!-- end searchform -->
                </div>


                                <a href="https://agladiadoraturismo.com/" class="aux-back-to-home"> <span class="aux-simple-arrow-left-symbol"></span> Bring me back home </a>

                            </div>

                       </article>

                    </div><!-- end content -->
                </div><!-- end primary -->


                

            </div><!-- end container -->
        </div><!-- end wrapper -->
    </main><!-- end main -->

		<div data-elementor-type="footer" data-elementor-id="71" class="elementor elementor-71 elementor-location-footer" data-elementor-post-type="elementor_library">
					<section class="elementor-section elementor-top-section elementor-element elementor-element-4867550 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4867550" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="aux-parallax-section elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-81d2083 aux-appear-watch-animation aux-fade-in" data-id="81d2083" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-f7510ac elementor-widget elementor-widget-image" data-id="f7510ac" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img width="270" height="210" src="https://agladiadoraturismo.com/wp-content/uploads/2019/10/logo-e-nome-logo-site-retina.png" class="attachment-large size-large wp-image-275" alt="" />													</div>
				</div>
				<div class="elementor-element elementor-element-da9ff63 elementor-widget elementor-widget-aux_icon_list" data-id="da9ff63" data-element_type="widget" data-widget_type="aux_icon_list.default">
				<div class="elementor-widget-container">
			<section class="widget-container aux-widget-icon-list aux-parent-au2a652b49" style="" ><div class="widget-inner"><div class="aux-widget-icon-list-inner"><ul class="aux-icon-list-items aux-direction-horizontal" ><li class="aux-icon-list-item aux-list-item-has-connector aux-list-item-has-icon aux-icon-list-item-7af8636 elementor-repeater-item-7af8636" ><a class="aux-icon-list-link" href="https://www.instagram.com/agladiadora.turismo/" ><span class="aux-icon-list-icon auxicon-instagram" ></span><span class="aux-list-connector" ></span></a></li><li class="aux-icon-list-item aux-list-item-has-connector aux-list-item-has-icon aux-icon-list-item-0d584e4 elementor-repeater-item-0d584e4" ><a class="aux-icon-list-link" href="https://www.facebook.com/agladiadora.turismo" ><span class="aux-icon-list-icon auxicon-facebook" ></span><span class="aux-list-connector" ></span></a></li></ul></div></div></section><!-- widget-container -->		</div>
				</div>
					</div>
		</div>
				<div class="aux-parallax-section elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-fd24b28 aux-appear-watch-animation aux-fade-in" data-id="fd24b28" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-2b90641 elementor-widget elementor-widget-aux_modern_heading" data-id="2b90641" data-element_type="widget" data-widget_type="aux_modern_heading.default">
				<div class="elementor-widget-container">
			<section class="aux-widget-modern-heading">
            <div class="aux-widget-inner"><h2 class="aux-modern-heading-primary">Acesso Rápido</h2></div>
        </section>		</div>
				</div>
				<div class="elementor-element elementor-element-8533daa elementor-widget elementor-widget-aux_icon_list" data-id="8533daa" data-element_type="widget" data-widget_type="aux_icon_list.default">
				<div class="elementor-widget-container">
			<section class="widget-container aux-widget-icon-list aux-parent-auee3e94a2" style="" ><div class="widget-inner"><div class="aux-widget-icon-list-inner"><ul class="aux-icon-list-items aux-direction-vertical" ><li class="aux-icon-list-item aux-list-item-has-connector aux-list-item-has-icon aux-icon-list-item-bcca7fd elementor-repeater-item-bcca7fd" ><a class="aux-icon-list-link" href="#" ><span class="aux-icon-list-text" >Home</span><span class="aux-list-connector" ></span></a></li><li class="aux-icon-list-item aux-list-item-has-connector aux-list-item-has-icon aux-icon-list-item-e03ca51 elementor-repeater-item-e03ca51" ><a class="aux-icon-list-link" href="https://agladiadoraturismo.com/calendario/" ><span class="aux-icon-list-text" >Calendário 2024</span><span class="aux-list-connector" ></span></a></li><li class="aux-icon-list-item aux-list-item-has-connector aux-list-item-has-icon aux-icon-list-item-9332705 elementor-repeater-item-9332705" ><a class="aux-icon-list-link" href="https://agladiadoraturismo.com/calendario_2025/" ><span class="aux-icon-list-text" >Calendário 2025</span><span class="aux-list-connector" ></span></a></li><li class="aux-icon-list-item aux-list-item-has-connector aux-list-item-has-icon aux-icon-list-item-81d3780 elementor-repeater-item-81d3780" ><a class="aux-icon-list-link" href="https://agladiadoraturismo.com/excursoes/" ><span class="aux-icon-list-text" >Excursões</span><span class="aux-list-connector" ></span></a></li><li class="aux-icon-list-item aux-list-item-has-connector aux-list-item-has-icon aux-icon-list-item-2e26e09 elementor-repeater-item-2e26e09" ><a class="aux-icon-list-link" href="https://agladiadoraturismo.com/sobre/" ><span class="aux-icon-list-text" >Sobre Nós</span><span class="aux-list-connector" ></span></a></li><li class="aux-icon-list-item aux-list-item-has-connector aux-list-item-has-icon aux-icon-list-item-2cd4694 elementor-repeater-item-2cd4694" ><a class="aux-icon-list-link" href="https://agladiadoraturismo.com/contato/" ><span class="aux-icon-list-text" >Contato</span><span class="aux-list-connector" ></span></a></li></ul></div></div></section><!-- widget-container -->		</div>
				</div>
					</div>
		</div>
				<div class="aux-parallax-section elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-0efe354 aux-appear-watch-animation aux-fade-in" data-id="0efe354" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-71e417f elementor-widget elementor-widget-aux_modern_heading" data-id="71e417f" data-element_type="widget" data-widget_type="aux_modern_heading.default">
				<div class="elementor-widget-container">
			<section class="aux-widget-modern-heading">
            <div class="aux-widget-inner"><h2 class="aux-modern-heading-primary">Contatos</h2></div>
        </section>		</div>
				</div>
				<div class="elementor-element elementor-element-9d91f7c elementor-widget elementor-widget-aux_modern_heading" data-id="9d91f7c" data-element_type="widget" data-widget_type="aux_modern_heading.default">
				<div class="elementor-widget-container">
			<section class="aux-widget-modern-heading">
            <div class="aux-widget-inner"><p class="aux-modern-heading-primary">+55 (43) 98429-8337 <br>R. Ronat Valter Sodré, 2112 San Rafael, Ibiporã - PR <br>CEP 86200-000</p></div>
        </section>		</div>
				</div>
					</div>
		</div>
				<div class="aux-parallax-section elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-902bb4f" data-id="902bb4f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-2a6c0a4 aux-appear-watch-animation aux-fade-in elementor-widget elementor-widget-aux_modern_heading" data-id="2a6c0a4" data-element_type="widget" data-widget_type="aux_modern_heading.default">
				<div class="elementor-widget-container">
			<section class="aux-widget-modern-heading">
            <div class="aux-widget-inner"><p class="aux-modern-heading-primary">Participe do nosso grupo no WhatsApp</p><h3 class="aux-modern-heading-secondary"><span class="aux-head-before">Receba em primeira mão os nossos lançamentos</span></h3></div>
        </section>		</div>
				</div>
				<div class="elementor-element elementor-element-ea010ac elementor-invisible elementor-widget elementor-widget-button" data-id="ea010ac" data-element_type="widget" data-settings="{&quot;_animation_mobile&quot;:&quot;fadeInUp&quot;,&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm elementor-animation-bounce-in" href="https://agladiadoraturismo.com/grupo_vip">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-icon">
				<i aria-hidden="true" class="fab fa-whatsapp"></i>			</span>
									<span class="elementor-button-text">Participar do Grupo no whatsapp</span>
					</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-c7ed88d elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c7ed88d" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="aux-parallax-section elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-971597e" data-id="971597e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-21b1fc6 elementor-widget elementor-widget-aux_copyright" data-id="21b1fc6" data-element_type="widget" data-widget_type="aux_copyright.default">
				<div class="elementor-widget-container">
			<small>&copy; 2024 A Gladiadora Turismo. Todos os direitos reservados.</small>		</div>
				</div>
					</div>
		</div>
				<div class="aux-parallax-section elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-1df32fb" data-id="1df32fb" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-e0bd0a4 elementor-widget elementor-widget-aux_modern_heading" data-id="e0bd0a4" data-element_type="widget" data-widget_type="aux_modern_heading.default">
				<div class="elementor-widget-container">
			<section class="aux-widget-modern-heading">
            <div class="aux-widget-inner"><p class="aux-modern-heading-primary">Política de Privacidade . Termos de Condição</p></div>
        </section>		</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
		
</div><!--! end of #inner-body -->

    <div class="aux-hidden-blocks">

        <section id="offmenu" class="aux-offcanvas-menu aux-pin-left" >
            <div class="aux-panel-close">
                <div class="aux-close aux-cross-symbol aux-thick-medium"></div>
            </div>
            <div class="offcanvas-header">
            </div>
            <div class="offcanvas-content">
            </div>
            <div class="offcanvas-footer">
            </div>
        </section>
        <!-- offcanvas section -->

        <section id="offcart" class="aux-offcanvas-menu aux-offcanvas-cart aux-pin-left" >
            <div class="aux-panel-close">
                <div class="aux-close aux-cross-symbol aux-thick-medium"></div>
            </div>
            <div class="offcanvas-header">
                Shopping Basket            </div>
            <div class="aux-cart-wrapper aux-elegant-cart aux-offcart-content">
            </div>
        </section>
        <!-- cartcanvas section -->

                <section id="fs-menu-search" class="aux-fs-popup  aux-fs-menu-layout-center aux-indicator">
            <div class="aux-panel-close">
                <div class="aux-close aux-cross-symbol aux-thick-medium"></div>
            </div>
            <div class="aux-fs-menu">
                        </div>
            <div class="aux-fs-search">
                <div  class="aux-search-section ">
                <div  class="aux-search-form ">
            <form action="https://agladiadoraturismo.com/" method="get" >
            <div class="aux-search-input-form">
                            <input type="text" class="aux-search-field"  placeholder="Type here.." name="s" autocomplete="off" />
                                    </div>
                            <input type="submit" class="aux-black aux-search-submit aux-uppercase" value="Search" >
                        </form>
        </div><!-- end searchform -->
                </div>

            </div>
        </section>
        <!-- fullscreen search and menu -->
                <section id="fs-search" class="aux-fs-popup aux-search-overlay  has-ajax-form">
            <div class="aux-panel-close">
                <div class="aux-close aux-cross-symbol aux-thick-medium"></div>
            </div>
            <div class="aux-search-field">

            <div  class="aux-search-section aux-404-search">
                <div  class="aux-search-form aux-iconic-search">
            <form action="https://agladiadoraturismo.com/" method="get" >
            <div class="aux-search-input-form">
                            <input type="text" class="aux-search-field"  placeholder="Search..." name="s" autocomplete="off" />
                                    </div>
                            <div class="aux-submit-icon-container auxicon-search-4 ">
                    <input type="submit" class="aux-iconic-search-submit" value="Search" >
                </div>
                        </form>
        </div><!-- end searchform -->
                </div>

            </div>
        </section>
        <!-- fullscreen search-->

        <div class="aux-scroll-top"></div>
    </div>

    <div class="aux-goto-top-btn aux-align-btn-right" data-animate-scroll="1"><div class="aux-hover-slide aux-arrow-nav aux-round aux-outline">    <span class="aux-overlay"></span>    <span class="aux-svg-arrow aux-h-small-up"></span>    <span class="aux-hover-arrow aux-svg-arrow aux-h-small-up aux-white"></span></div></div>
<!-- outputs by wp_footer -->
<!-- Instagram Feed JS -->
<script type="text/javascript">
var sbiajaxurl = "https://agladiadoraturismo.com/wp-admin/admin-ajax.php";
</script>
    <!-- Meta Pixel Event Code -->
    <script type='text/javascript'>
        document.addEventListener( 'wpcf7mailsent', function( event ) {
        if( "fb_pxl_code" in event.detail.apiResponse){
          eval(event.detail.apiResponse.fb_pxl_code);
        }
      }, false );
    </script>
    <!-- End Meta Pixel Event Code -->
    		<div class="shopengine-quick-view-modal se-modal-wrapper"></div>
				<div class="shopengine-comparison-modal se-modal-wrapper">
			<div class="se-modal-inner"></div>
		</div>
					<script type='text/javascript'>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<noscript><img loading="lazy" height="1" width="1" style="display: none;" src="https://www.facebook.com/tr?id=1480964285602159&ev=PageView&noscript=1&cd%5Bpost_type%5D&cd%5Bplugin%5D=PixelYourSite&cd%5Buser_role%5D=guest&cd%5Bevent_url%5D=agladiadoraturismo.com%2Fsignals%2Fiwl.js" alt=""></noscript>
	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<link rel='stylesheet' id='font-awesome-5-all-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css?ver=3.24.4' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-4-shim-css' href='https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min.css?ver=3.24.4' type='text/css' media='all' />
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-includes/js/imagesloaded.min.js?ver=5.0.0" id="imagesloaded-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-includes/js/masonry.min.js?ver=4.2.2" id="masonry-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/themes/phlox/js/plugins.min.js?ver=2.9.1" id="auxin-plugins-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/themes/phlox/js/scripts.min.js?ver=2.9.1" id="auxin-scripts-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/auxin-elements/admin/assets/js/elementor/widgets.js?ver=2.10.5" id="auxin-elementor-widgets-js"></script>
<script type="text/javascript" id="mediaelement-core-js-before">
/* <![CDATA[ */
var mejsL10n = {"language":"pt","strings":{"mejs.download-file":"Fazer download do arquivo","mejs.install-flash":"Voc\u00ea est\u00e1 usando um navegador que n\u00e3o tem Flash ativo ou instalado. Ative o plugin do Flash player ou baixe a \u00faltima vers\u00e3o em https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Tela inteira","mejs.play":"Reproduzir","mejs.pause":"Pausar","mejs.time-slider":"Tempo do slider","mejs.time-help-text":"Use as setas esquerda e direita para avan\u00e7ar um segundo. Acima e abaixo para avan\u00e7ar dez segundos.","mejs.live-broadcast":"Transmiss\u00e3o ao vivo","mejs.volume-help-text":"Use as setas para cima ou para baixo para aumentar ou diminuir o volume.","mejs.unmute":"Desativar mudo","mejs.mute":"Mudo","mejs.volume-slider":"Controle de volume","mejs.video-player":"Tocador de v\u00eddeo","mejs.audio-player":"Tocador de \u00e1udio","mejs.captions-subtitles":"Transcri\u00e7\u00f5es\/Legendas","mejs.captions-chapters":"Cap\u00edtulos","mejs.none":"Nenhum","mejs.afrikaans":"Afric\u00e2ner","mejs.albanian":"Alban\u00eas","mejs.arabic":"\u00c1rabe","mejs.belarusian":"Bielorrusso","mejs.bulgarian":"B\u00falgaro","mejs.catalan":"Catal\u00e3o","mejs.chinese":"Chin\u00eas","mejs.chinese-simplified":"Chin\u00eas (simplificado)","mejs.chinese-traditional":"Chin\u00eas (tradicional)","mejs.croatian":"Croata","mejs.czech":"Checo","mejs.danish":"Dinamarqu\u00eas","mejs.dutch":"Holand\u00eas","mejs.english":"Ingl\u00eas","mejs.estonian":"Estoniano","mejs.filipino":"Filipino","mejs.finnish":"Finland\u00eas","mejs.french":"Franc\u00eas","mejs.galician":"Galega","mejs.german":"Alem\u00e3o","mejs.greek":"Grego","mejs.haitian-creole":"Crioulo haitiano","mejs.hebrew":"Hebraico","mejs.hindi":"Hindi","mejs.hungarian":"H\u00fangaro","mejs.icelandic":"Island\u00eas","mejs.indonesian":"Indon\u00e9sio","mejs.irish":"Irland\u00eas","mejs.italian":"Italiano","mejs.japanese":"Japon\u00eas","mejs.korean":"Coreano","mejs.latvian":"Let\u00e3o","mejs.lithuanian":"Lituano","mejs.macedonian":"Maced\u00f4nio","mejs.malay":"Malaio","mejs.maltese":"Malt\u00eas","mejs.norwegian":"Noruegu\u00eas","mejs.persian":"Persa","mejs.polish":"Polon\u00eas","mejs.portuguese":"Portugu\u00eas","mejs.romanian":"Romeno","mejs.russian":"Russo","mejs.serbian":"S\u00e9rvio","mejs.slovak":"Eslovaco","mejs.slovenian":"Esloveno","mejs.spanish":"Espanhol","mejs.swahili":"Sua\u00edli","mejs.swedish":"Sueco","mejs.tagalog":"Tagalo","mejs.thai":"Tailand\u00eas","mejs.turkish":"Turco","mejs.ukrainian":"Ucraniano","mejs.vietnamese":"Vietnamita","mejs.welsh":"Gal\u00eas","mejs.yiddish":"I\u00eddiche"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=4.2.17" id="mediaelement-core-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-includes/js/mediaelement/mediaelement-migrate.min.js?ver=6.6.2" id="mediaelement-migrate-js"></script>
<script type="text/javascript" id="mediaelement-js-extra">
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"auto","audioShortcodeLibrary":"mediaelement","videoShortcodeLibrary":"mediaelement"};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=6.6.2" id="wp-mediaelement-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/auxin-elements/public/assets/js/plugins.min.js?ver=2.10.5" id="auxin-elements-plugins-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/auxin-elements/public/assets/js/scripts.js?ver=2.10.5" id="auxin-elements-scripts-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.6.4" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/agladiadoraturismo.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.6.4" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/woocommerce/assets/js/flexslider/jquery.flexslider.min.js?ver=2.7.2-wc.7.0.0" id="flexslider-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.7.0.0" id="jquery-blockui-js"></script>
<script type="text/javascript" id="wc-add-to-cart-js-extra">
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"Ver carrinho","cart_url":"https:\/\/agladiadoraturismo.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=7.0.0" id="wc-add-to-cart-js"></script>
<script type="text/javascript" id="woocommerce-js-extra">
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=7.0.0" id="woocommerce-js"></script>
<script type="text/javascript" id="wc-cart-fragments-js-extra">
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_4b3ccef74d87d7799c33a13b6a9a461f","fragment_name":"wc_fragments_4b3ccef74d87d7799c33a13b6a9a461f","request_timeout":"5000"};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=7.0.0" id="wc-cart-fragments-js"></script>
<script type="text/javascript" id="wp_ulike-js-extra">
/* <![CDATA[ */
var wp_ulike_params = {"ajax_url":"https:\/\/agladiadoraturismo.com\/wp-admin\/admin-ajax.php","notifications":"1"};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/wp-ulike/assets/js/wp-ulike.min.js?ver=4.6.4" id="wp_ulike-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/shopengine/assets/js/simple-scrollbar.js?ver=2.5.1" id="shopengine-simple-scrollbar.js-js-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/shopengine/assets/js/filter.js?ver=2.5.1" id="shopengine-filter-js-js"></script>
<script type="text/javascript" id="shopengine-js-js-extra">
/* <![CDATA[ */
var shopEngineApiSettings = {"resturl":"https:\/\/agladiadoraturismo.com\/wp-json\/","rest_nonce":"352a750552"};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/shopengine/assets/js/public.js?ver=2.5.1" id="shopengine-js-js"></script>
<script type="text/javascript" id="wd-asl-ajaxsearchlite-js-before">
/* <![CDATA[ */
window.ASL = typeof window.ASL !== 'undefined' ? window.ASL : {}; window.ASL.wp_rocket_exception = "DOMContentLoaded"; window.ASL.ajaxurl = "https:\/\/agladiadoraturismo.com\/wp-admin\/admin-ajax.php"; window.ASL.backend_ajaxurl = "https:\/\/agladiadoraturismo.com\/wp-admin\/admin-ajax.php"; window.ASL.js_scope = "jQuery"; window.ASL.asl_url = "https:\/\/agladiadoraturismo.com\/wp-content\/plugins\/ajax-search-lite\/"; window.ASL.detect_ajax = 1; window.ASL.media_query = 4765; window.ASL.version = 4765; window.ASL.pageHTML = ""; window.ASL.additional_scripts = [{"handle":"wd-asl-ajaxsearchlite","src":"https:\/\/agladiadoraturismo.com\/wp-content\/plugins\/ajax-search-lite\/js\/min\/plugin\/optimized\/asl-prereq.js","prereq":[]},{"handle":"wd-asl-ajaxsearchlite-core","src":"https:\/\/agladiadoraturismo.com\/wp-content\/plugins\/ajax-search-lite\/js\/min\/plugin\/optimized\/asl-core.js","prereq":[]},{"handle":"wd-asl-ajaxsearchlite-vertical","src":"https:\/\/agladiadoraturismo.com\/wp-content\/plugins\/ajax-search-lite\/js\/min\/plugin\/optimized\/asl-results-vertical.js","prereq":["wd-asl-ajaxsearchlite"]},{"handle":"wd-asl-ajaxsearchlite-autocomplete","src":"https:\/\/agladiadoraturismo.com\/wp-content\/plugins\/ajax-search-lite\/js\/min\/plugin\/optimized\/asl-autocomplete.js","prereq":["wd-asl-ajaxsearchlite"]},{"handle":"wd-asl-ajaxsearchlite-load","src":"https:\/\/agladiadoraturismo.com\/wp-content\/plugins\/ajax-search-lite\/js\/min\/plugin\/optimized\/asl-load.js","prereq":["wd-asl-ajaxsearchlite-autocomplete"]}]; window.ASL.script_async_load = false; window.ASL.init_only_in_viewport = true; window.ASL.font_url = "https:\/\/agladiadoraturismo.com\/wp-content\/plugins\/ajax-search-lite\/css\/fonts\/icons2.woff2"; window.ASL.css_async = false; window.ASL.highlight = {"enabled":false,"data":[]}; window.ASL.analytics = {"method":0,"tracking_id":"","string":"?ajax_search={asl_term}","event":{"focus":{"active":1,"action":"focus","category":"ASL","label":"Input focus","value":"1"},"search_start":{"active":0,"action":"search_start","category":"ASL","label":"Phrase: {phrase}","value":"1"},"search_end":{"active":1,"action":"search_end","category":"ASL","label":"{phrase} | {results_count}","value":"1"},"magnifier":{"active":1,"action":"magnifier","category":"ASL","label":"Magnifier clicked","value":"1"},"return":{"active":1,"action":"return","category":"ASL","label":"Return button pressed","value":"1"},"facet_change":{"active":0,"action":"facet_change","category":"ASL","label":"{option_label} | {option_value}","value":"1"},"result_click":{"active":1,"action":"result_click","category":"ASL","label":"{result_title} | {result_url}","value":"1"}}};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/ajax-search-lite/js/min/plugin/optimized/asl-prereq.js?ver=4765" id="wd-asl-ajaxsearchlite-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/ajax-search-lite/js/min/plugin/optimized/asl-core.js?ver=4765" id="wd-asl-ajaxsearchlite-core-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/ajax-search-lite/js/min/plugin/optimized/asl-results-vertical.js?ver=4765" id="wd-asl-ajaxsearchlite-vertical-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/ajax-search-lite/js/min/plugin/optimized/asl-autocomplete.js?ver=4765" id="wd-asl-ajaxsearchlite-autocomplete-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/ajax-search-lite/js/min/plugin/optimized/asl-load.js?ver=4765" id="wd-asl-ajaxsearchlite-load-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/ajax-search-lite/js/min/plugin/optimized/asl-wrapper.js?ver=4765" id="wd-asl-ajaxsearchlite-wrapper-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/elementskit-lite/libs/framework/assets/js/frontend-script.js?ver=2.7.3" id="elementskit-framework-js-frontend-js"></script>
<script type="text/javascript" id="elementskit-framework-js-frontend-js-after">
/* <![CDATA[ */
		var elementskit = {
			resturl: 'https://agladiadoraturismo.com/wp-json/elementskit/v1/',
		}

		
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/elementskit-lite/widgets/init/assets/js/widget-scripts.js?ver=2.7.3" id="ekit-widget-scripts-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/shopengine/modules/swatches/loop-product-support/assets/swatches.js?ver=1515155" id="shopengine-swatches-loop-js-js"></script>
<script type="text/javascript" id="shopengine-comparison-js-extra">
/* <![CDATA[ */
var shopEngineComparison = {"product_id":"","resturl":"https:\/\/agladiadoraturismo.com\/wp-json\/","rest_nonce":"352a750552"};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/shopengine/modules/comparison/assets/js/comparison.js?ver=2.5.1" id="shopengine-comparison-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/uploads/wpmss/wpmssab.min.js?ver=1644556420" id="wpmssab-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/mousewheel-smooth-scroll/js/SmoothScroll.min.js?ver=1.4.10" id="SmoothScroll-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/uploads/wpmss/wpmss.min.js?ver=1644556420" id="wpmss-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/shopengine/modules/swatches/assets/js/frontend.js?ver=2.5.1" id="shopengine-js-front-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/uploads/phlox/custom.js?ver=5.3" id="auxin-custom-js-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=3.24.4" id="font-awesome-4-shim-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/jetsticky-for-elementor/assets/js/lib/ResizeSensor.min.js?ver=1.7.0" id="jet-resize-sensor-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/jetsticky-for-elementor/assets/js/lib/sticky-sidebar/sticky-sidebar.min.js?ver=3.3.1" id="jet-sticky-sidebar-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/jetsticky-for-elementor/assets/js/lib/jsticky/jquery.jsticky.js?ver=1.1.0" id="jsticky-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.min.js?ver=3.24.2" id="elementor-pro-webpack-runtime-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.24.4" id="elementor-webpack-runtime-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.24.4" id="elementor-frontend-modules-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-includes/js/dist/hooks.min.js?ver=2810c76e705dd1a53b18" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" id="elementor-pro-frontend-js-before">
/* <![CDATA[ */
var ElementorProFrontendConfig = {"ajaxurl":"https:\/\/agladiadoraturismo.com\/wp-admin\/admin-ajax.php","nonce":"325544dd65","urls":{"assets":"https:\/\/agladiadoraturismo.com\/wp-content\/plugins\/elementor-pro\/assets\/","rest":"https:\/\/agladiadoraturismo.com\/wp-json\/"},"settings":{"lazy_load_background_images":true},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"},"x-twitter":{"title":"X"},"threads":{"title":"Threads"}},"woocommerce":{"menu_cart":{"cart_page_url":"https:\/\/agladiadoraturismo.com\/cart\/","checkout_page_url":"https:\/\/agladiadoraturismo.com\/checkout\/","fragments_nonce":"8da14ed98b"}},"facebook_sdk":{"lang":"pt_BR","app_id":""},"lottie":{"defaultAnimationUrl":"https:\/\/agladiadoraturismo.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.24.2" id="elementor-pro-frontend-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script type="text/javascript" id="elementor-frontend-js-before">
/* <![CDATA[ */
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Compartilhar no Facebook","shareOnTwitter":"Compartilhar no Twitter","pinIt":"Fixar","download":"Baixar","downloadImage":"Baixar imagem","fullscreen":"Tela cheia","zoom":"Zoom","share":"Compartilhar","playVideo":"Reproduzir v\u00eddeo","previous":"Anterior","next":"Pr\u00f3ximo","close":"Fechar","a11yCarouselWrapperAriaLabel":"Carrossel | Rolagem horizontal: Setas para esquerda e direita","a11yCarouselPrevSlideMessage":"Slide anterior","a11yCarouselNextSlideMessage":"Pr\u00f3ximo slide","a11yCarouselFirstSlideMessage":"Este \u00e9 o primeiro slide","a11yCarouselLastSlideMessage":"Este \u00e9 o \u00faltimo slide","a11yCarouselPaginationBulletMessage":"Ir para o slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Dispositivos m\u00f3veis no modo retrato","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Dispositivos m\u00f3veis no modo paisagem","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet no modo retrato","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet no modo paisagem","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Notebook","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Tela ampla (widescreen)","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.24.4","is_static":false,"experimentalFeatures":{"additional_custom_breakpoints":true,"container_grid":true,"e_swiper_latest":true,"e_nested_atomic_repeaters":true,"e_onboarding":true,"theme_builder_v2":true,"home_screen":true,"ai-layout":true,"landing-pages":true,"link-in-bio":true,"floating-buttons":true,"display-conditions":true,"form-submissions":true},"urls":{"assets":"https:\/\/agladiadoraturismo.com\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"https:\/\/agladiadoraturismo.com\/wp-admin\/admin-ajax.php"},"nonces":{"floatingButtonsClickTracking":"efe65d8766"},"swiperClass":"swiper","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description","woocommerce_notices_elements":[]},"post":{"id":0,"title":"P\u00e1gina n\u00e3o encontrada &#8211; A Gladiadora Turismo","excerpt":""}};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.24.4" id="elementor-frontend-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/elementor-pro/assets/js/elements-handlers.min.js?ver=3.24.2" id="pro-elements-handlers-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/shopengine/widgets/init/assets/js/widgets.js?ver=2.5.1" id="shopengine-elementor-script-js"></script>
<script type="text/javascript" id="jet-sticky-frontend-js-extra">
/* <![CDATA[ */
var JetStickySettings = {"elements_data":{"sections":[],"columns":[]}};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/jetsticky-for-elementor/assets/js/jet-sticky-frontend.js?ver=1.0.3" id="jet-sticky-frontend-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/elementskit-lite/widgets/init/assets/js/animate-circle.js?ver=2.7.3" id="animate-circle-js"></script>
<script type="text/javascript" id="elementskit-elementor-js-extra">
/* <![CDATA[ */
var ekit_config = {"ajaxurl":"https:\/\/agladiadoraturismo.com\/wp-admin\/admin-ajax.php","nonce":"5787e5f1c5"};
/* ]]> */
</script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/elementskit-lite/widgets/init/assets/js/elementor.js?ver=2.7.3" id="elementskit-elementor-js"></script>
<script type="text/javascript" src="https://agladiadoraturismo.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=2.7.3" id="swiper-js"></script>
<!-- end wp_footer -->
</body>
</html>
